1.环境安装依赖
bash
运行
pip install numpy scipy matplotlib
2.运行方式
直接运行 fem_solver_main.py，程序会自动依次执行全部 7 个算例，输出文本结果 + 绘图。
3.文件说明
运行后自动生成 example_n5.json（PPT 标准算例输入文件）；
所有数组下标统一从 0 开始；
包含作业要求的：稠密 LDLT、活动列 colsol、非正定检测、病态分析、JSON 读写、稀疏 PARDISO、桁架 + Poisson 有限元全内容。
4.扩展说明
可修改 run_poisson_fem(nx,ny) 调整网格密度；
可对接 2.3 作业的单元组装模块，替换桁架 / 刚度矩阵生成部分；
可新增多载荷工况循环，验证 “一次分解、多次回代” 效率。