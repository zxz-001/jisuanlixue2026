运行环境
Python 3.6+，依赖：numpy、matplotlib
安装：
bash
运行
pip install numpy matplotlib
文件说明
3-8源代码.txt：主程序
advection_diffusion_Pe0.1/3.0.png：不同佩克莱数结果对比图
convergence_study.png：网格收敛曲线
主要功能
输出节点数据、数值解与精确解
两种 Pe 数下多格式对比、绘图及误差统计
矩阵对称性、正定性分析，解释数值振荡原因
网格收敛性与收敛阶计算
运行命令
bash
运行
python 3-8源代码.txt
运行后控制台输出结果，自动生成图片。
简要结论
扩散占优（低 Pe）：三种格式精度表现良好；
对流占优（高 Pe）：标准 Galerkin 易振荡，迎风格式、SUPG 稳定性更佳；
对流项造成矩阵非对称、非正定，是振荡主要诱因；
网格加密后误差减小，SUPG 综合精度最优。