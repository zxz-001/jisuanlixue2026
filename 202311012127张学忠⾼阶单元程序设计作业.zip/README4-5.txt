高阶等参单元有限元程序项目简介
基于 Python 实现 Q4、Q8、Q9 三类四边形等参单元，求解二维 Poisson 方程，完成形函数检验、Jacobian 计算、高斯积分、完备性测试、误差分析、静力凝聚等作业要求。运行环境Python 3.8+
依赖库：numpy、matplotlib、scipy
安装命令：bash运行pip install numpy matplotlib scipy
文件说明程序设计源代码.py：主程序，包含全部算法、算例与绘图功能。核心功能
实现 Q4/Q8/Q9 单元形函数、等参映射与 Jacobian 检测
高斯积分、有限元方程组装与求解
Patch Test 单元完备性检验
误差、矩阵条件数计算
Q9 单元内部节点静力凝聚
自动生成数值解、误差云图及收敛曲线
控制方程求解单位正方形区域 Poisson 方程：
\(-\Delta u = 2\pi^2\sin(\pi x)\sin(\pi y),\quad u\big|_{\partial\Omega}=0\)
理论解：\(u(x,y)=\sin(\pi x)\sin(\pi y)\)运行方法
代码放置在纯英文路径下；
终端 / 编辑器直接运行：
bash运行python 程序设计源代码.py

程序全自动执行，无需手动传参。
输出内容1. 控制台输出
三类单元完备性测试误差
4×4、8×8 网格的节点数、自由度数、最大误差、L₂相对误差、矩阵条件数
Q9 静力凝聚前后矩阵尺寸与计算结果
2. 图片输出（同目录自动生成）
Q4_sol_8x8.png  Q4 单元 8×8 网格数值解云图
Q4_err_8x8.png  Q4 单元 8×8 网格绝对误差云图
Q8_sol_8x8.png  Q8 单元 8×8 网格数值解云图
Q8_err_8x8.png  Q8 单元 8×8 网格绝对误差云图
Q9_sol_8x8.png  Q9 单元 8×8 网格数值解云图
Q9_err_8x8.png  Q9 单元 8×8 网格绝对误差云图
convergence_curve.png  三类单元收敛曲线对比
积分规则
Q4：2×2 高斯积分
Q8、Q9：3×3 高斯积分
常见问题
库缺失：执行依赖安装命令；
Jacobian 警告：代码已设置阈值自动跳过畸变积分，属于正常现象；
运行缓慢：删除mesh_sizes中的16，仅保留 4、8 网格。